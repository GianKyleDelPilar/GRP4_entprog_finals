﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Suits.DataModel
{
    public class RentalDetails
    {
        public int Id { get; set; }
        public int RentalHeaderId { get; set; }
        public RentalHeader RentalHeader { get; set; }
        public int SuitId { get; set; }
        public Suit Suit { get; set; }
        public int Qty { get; set; }
        public decimal Price { get; set; }
        public decimal Amount { get; set; }
    }
}
