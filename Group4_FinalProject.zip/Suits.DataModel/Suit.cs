﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Suits.DataModel
{
    public class Suit
    {
        public int SuitID { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public int Price { get; set; }
        public int Qty { get; set; }
        public string SuitType { get; set; }
        public string Location { get; set; }
        public DateTime DateAdded { get; set; } = DateTime.Now;
        public DateTime? DateModified { get; set; } = DateTime.Now;
    }
}
