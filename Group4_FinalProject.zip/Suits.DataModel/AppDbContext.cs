﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Suits.DataModel
{
    public class AppDbContext : IdentityDbContext
    {
        public AppDbContext(DbContextOptions options) : base(options)
        {

        }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (optionsBuilder.IsConfigured == false)
            {
                optionsBuilder.UseSqlServer("Server=Desktop-EDG1IN1\\SQLEXPRESS;" +
                "Database=eisensy_csbentprog;uid=eisensy_student;pwd=Benilde@2020" +
                "Integrated Security=true;TrustServerCertificate=true");
            }
        }

        public DbSet<Suit> Suits { get; set; }
        public DbSet<Customer> Customers { get; set; }
        public DbSet<RentalHeader> RentalHeadersINV { get; set; }
        public DbSet<RentalDetails> RentalDetailsINV { get; set; }

    }

}
