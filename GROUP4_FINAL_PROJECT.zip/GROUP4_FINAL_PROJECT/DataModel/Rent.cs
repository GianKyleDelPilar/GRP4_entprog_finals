﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataModel
{
    public class Rent
    {
        [Key]
        public int RentID { get; set; }
        public int SuitID { get; set; }
        public string CustomerName { get; set; }
        public DateTime RentDate { get; set; }
        public DateTime ReturnDate { get; set; }
        public decimal TotalCost { get; set; }
        public DateTime DateAdded { get; private set; } = DateTime.Now;
        public DateTime? DateModified { get; set; } = DateTime.Now;
    }
}