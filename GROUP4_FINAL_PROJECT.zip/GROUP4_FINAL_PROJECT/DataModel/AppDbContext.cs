﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataModel
{
    public class RentalSuitDbContext : DbContext
    {
        public RentalSuitDbContext(DbContextOptions options) : base(options)
        {

        }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
           
                optionsBuilder.UseSqlServer("Server=DESKTOP-09VHFQKJ\\SQLEXPRESS;" +
                "Database=Group4_FinalProject;" +
                "Integrated Security=true;TrustServerCertificate=true");
            
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<Suit>().ToTable("SuitsINV");
            modelBuilder.Entity<Suit>().Property(p => p.Name).HasColumnName("Name");
            modelBuilder.Entity<Suit>().Property(p => p.Description).HasColumnName("Description");
            modelBuilder.Entity<Suit>().Property(p => p.Price).HasColumnName("Price");
            modelBuilder.Entity<Suit>().Property(p => p.IsAvailable).HasColumnName("IsAvailable");
            modelBuilder.Entity<Suit>().Property(p => p.DateAdded).HasColumnName("DateAdded");
            modelBuilder.Entity<Suit>().Property(p => p.DateModified).HasColumnName("DateModified");
            modelBuilder.Entity<Suit>().Property(p => p.Name).HasColumnType("nvarchar(max)");
            modelBuilder.Entity<Suit>().Property(p => p.Description).HasColumnType("nvarchar(max)");
            modelBuilder.Entity<Suit>().Property(p => p.Price).HasColumnType("decimal(18, 2)");
            modelBuilder.Entity<Suit>().Property(p => p.IsAvailable).HasColumnType("bit");
            modelBuilder.Entity<Suit>().Property(p => p.DateAdded).HasColumnType("datetime2(7)");
            modelBuilder.Entity<Suit>().Property(p => p.DateModified).IsRequired(false);

            modelBuilder.Entity<Suit>().HasData(new Suit
            {
                SuitID = 1,
                Name = "Test",
                Description = "Manila",
                Price = 100.00m,
                IsAvailable = true

            });

            modelBuilder.Entity<Rent>().ToTable("RentINV");
            modelBuilder.Entity<Rent>().Property(p => p.SuitID).HasColumnName("SuitID");
            modelBuilder.Entity<Rent>().Property(p => p.CustomerName).HasColumnName("CustomerName");
            modelBuilder.Entity<Rent>().Property(p => p.RentDate).HasColumnName("RentDate");
            modelBuilder.Entity<Rent>().Property(p => p.ReturnDate).HasColumnName("ReturnDate");
            modelBuilder.Entity<Rent>().Property(p => p.TotalCost).HasColumnName("TotalCost");
            modelBuilder.Entity<Rent>().Property(p => p.SuitID).HasColumnType("int");
            modelBuilder.Entity<Rent>().Property(p => p.CustomerName).HasColumnType("nvarchar(max)");
            modelBuilder.Entity<Rent>().Property(p => p.RentDate).HasColumnType("datetime2(7)");
            modelBuilder.Entity<Rent>().Property(p => p.ReturnDate).HasColumnType("datetime2(7)");
            modelBuilder.Entity<Rent>().Property(p => p.TotalCost).HasColumnType("decimal(18, 2)");

            modelBuilder.Entity<Rent>().HasData(new Rent
            {
                RentID = 1,
                SuitID = 1,
                CustomerName = "Test",
                RentDate = DateTime.Now,
                ReturnDate = DateTime.Now.AddDays(1),
                TotalCost = 100.00m

            });

            modelBuilder.Entity<Return>().ToTable("ReturnINV");
            modelBuilder.Entity<Return>().Property(p => p.RentID).HasColumnName("RentID");
            modelBuilder.Entity<Return>().Property(p => p.ReturnDate).HasColumnName("ReturnDate");
            modelBuilder.Entity<Return>().Property(p => p.Fine).HasColumnName("Fine");
            modelBuilder.Entity<Return>().Property(p => p.RentID).HasColumnType("int");
            modelBuilder.Entity<Return>().Property(p => p.ReturnDate).HasColumnType("datetime2(7)");
            modelBuilder.Entity<Return>().Property(p => p.Fine).HasColumnType("decimal(18, 2)");

            modelBuilder.Entity<Return>().HasData(new Return
            {
                ReturnID = 1,
                RentID = 1,
                ReturnDate = DateTime.Now.AddDays(1),
                Fine = 0.00m

            });
        }

        public DbSet<Suit> Suits { get; set; }
        public DbSet<Rent> Rents { get; set; }
        public DbSet<Return> Returns { get; set; }
    }
}