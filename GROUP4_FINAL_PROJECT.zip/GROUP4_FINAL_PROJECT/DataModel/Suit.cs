﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataModel
{
    public class Suit
    {
        [Key]
        public int SuitID { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public decimal Price { get; set; }
        public bool IsAvailable { get; set; }
        public DateTime DateAdded { get; private set; } = DateTime.Now;
        public DateTime? DateModified { get; set; } = DateTime.Now;
    }
}