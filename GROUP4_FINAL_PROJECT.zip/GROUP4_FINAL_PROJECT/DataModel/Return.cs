﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataModel
{
    public class Return
    {
        [Key]
        public int ReturnID { get; set; }
        public int RentID { get; set; }
        public DateTime ReturnDate { get; set; }
        public decimal Fine { get; set; }
        public DateTime DateAdded { get; private set; } = DateTime.Now;
        public DateTime? DateModified { get; set; } = DateTime.Now;
    }
}