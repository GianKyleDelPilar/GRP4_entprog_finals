﻿namespace Group4_ENTPROG_Finals
{
    public class Class1
    {

    }
}
